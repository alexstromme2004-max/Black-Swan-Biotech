# Black Swan Biotech — website

## What's in here
- `index.html` — Home
- `technology.html` — Our Technology (NeuroPMO™, evidence chart, pathways, pipeline, precision-vs-traditional diagrams)
- `about.html` — About Us (who we serve, real team photos, mission)
- `contact.html` — Contact (form, contact info, partner logos)
- `assets/style.css` — shared styling (Space Grotesk + Inter + IBM Plex Mono, single blue accent)
- `assets/script.js` — mobile menu + scroll animation + contact form handler
- `assets/logo.svg` — the logo mark (a single-line swan neck/head in the brand blue)
- `assets/team/` — the 10 real headshots, cropped and squared from your screenshots
- `assets/art/` — three original glowing neuron-network images (amber, blue, green)
  used as hero/banner imagery
- `assets/logos/` — empty folder; drop partner logo files here once you have them

## About the neuron imagery
Rather than reuse the stock photos from your reference screenshots — whose
licensing I couldn't verify for a live commercial site — I generated original
neuron-network artwork that matches the same glowing, branching, fluorescent
look. It's yours to use freely with no attribution or licensing concerns.
If you'd prefer real microscopy photography later, these are drop-in
replacements: swap the files in `assets/art/` (same filenames) and everything
else stays the same.

## About the team photos
These are cropped directly from the screenshots you shared — same people,
tightened to a square crop for the grid. Masha Stromme's photo is used in
both Management and Board Members, matching your source material.

## About the logo
A simple, refined mark: a single continuous line forming a swan's neck and
head, in the brand blue, with a short "water line" beneath — paired with the
wordmark "Black Swan" and a small "BIOTECH" tag. No box, no illustration,
just a clean signature you can keep or hand to a designer to develop further.

## Things still marked as placeholders
Search each page for "▸" to find every spot that still needs real content:
- Office address, LinkedIn URLs, and map — contact.html
- Partner logo image files — contact.html shows plain text names until logos
  are added to `assets/logos/`
- Real pipeline stage data — technology.html (bar widths are illustrative)
- PRKN pathway description — technology.html
- News items — index.html ("Insights & Updates" is placeholder copy)

## Going live — free hosting options

**Netlify Drop (easiest, no account needed to start)**
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page
3. You'll get a live URL immediately (e.g. `random-name.netlify.app`)
4. Create a free Netlify account to keep the site and later attach your own
   domain name (Site settings → Domain management)

**GitHub Pages**
1. Create a new GitHub repository and upload these files
2. Settings → Pages → set source to the `main` branch, root folder
3. You'll get `yourname.github.io/repo-name`, with custom domain support
   under Settings → Pages → Custom domain

**Cloudflare Pages**
1. Go to https://pages.cloudflare.com
2. Connect a GitHub repo, or drag-and-drop the folder via direct upload
3. You'll get a `*.pages.dev` URL, with custom domain support

A custom domain (e.g. blackswanbio.com) is bought separately from a
registrar and then pointed at whichever host you pick.

## The contact form
Right now the form doesn't send anywhere — it shows a note asking people to
email directly. To make it actually deliver messages:
- **Formspree** (formspree.io) — free tier, point the form's `action` at the
  endpoint they give you
- **Netlify Forms** — if you host on Netlify, add a `netlify` attribute to
  the form and it works automatically

Happy to wire either of these up once you've picked one.
